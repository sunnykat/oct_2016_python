from django.conf.urls import url, include
from . import views

urlpatterns = [
    url(r'^$', views.index, name='index'),
    url(r'^process', views.process, name='process'),
    url(r'^destroy/(?P<c_id>\d+$)', views.destroy),
    url(r'^delete/(?P<c_id>\d+$)', views.delete, name='delete'),
    url(r'^comment/(?P<c_id>\d+$)', views.comment, name='comment'),
    url(r'^destroy', views.index, name='destroy'),
    url(r'^add', views.add, name='add'),
    url(r'^all', views.all, name='all')

]

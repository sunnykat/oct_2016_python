from __future__ import unicode_literals

from django.db import models
from ..login.models import User
# Create your models here.

class CourseManager(models.Manager):
    def add_to_course(self, form_data):
        course=self.get(id=form_data['course'])
        user=User.objects.get(id=form_data['user'])
        course.users.add(user)
        course.save()

class Courses(models.Model):
    names=models.CharField(max_length=100)
    desc=models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    users=models.ManyToManyField('login.User', related_name='courses')

    objects=CourseManager()

class Comments(models.Model):
    comment=models.TextField()
    cor_id=models.ForeignKey(Courses, to_field='id')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

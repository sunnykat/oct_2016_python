from django.shortcuts import render, redirect
from django.db.models import Count
from django.core.urlresolvers import reverse
from .models import Courses, Comments
from ..login.models import User

# Create your views here.

def index(request):
    context={
    'data':Courses.objects.all()
    }
    return render(request, 'course/index.html', context )

def process(request):
    Courses.objects.create(names=str(request.POST['name']), desc=str(request.POST['desc']))
    return redirect (reverse('courses:index'))

def destroy(request, c_id):
    context={
    'data':Courses.objects.get(pk=c_id)
    }
    return render(request, 'course/delete.html', context)

def delete(request, c_id):
    temp=Courses.objects.get(id=c_id).delete()
    return redirect(reverse ('courses:index'))

def comment(request, c_id):
    if request.POST:
        Comments.objects.create(comment=str(request.POST['com']), cor_id=c_id )
        return redirect('course/comment/'+str(c_id))

    else:
        context={
        'data':Courses.objects.filter(pk=c_id),
        'comm':Comments.objects.filter(cor_id=c_id),
        'id':c_id,
        }

        return render(request, 'course/comments.html', context)
def add(request):
    Courses.objects.add_to_course(request.POST)
    return redirect(reverse('courses:all'))
def all(request):
    context={
    'courses':Courses.objects.annotate(students=Count('users')),
    'users':User.objects.all()
    }
    return render(request, 'course/usercourse.html', context)

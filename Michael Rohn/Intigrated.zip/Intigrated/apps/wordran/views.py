from django.shortcuts import render, redirect
import random, string


def randomword(length):
    return ''.join(random.choice(string.lowercase) for i in range(length))

# Create your views here.
def index(request):
    if 'count' not in request.session:
        request.session['count']=0
    request.session['count']=request.session['count']+1
    context={"word":randomword(14)}
    return render(request,'wordran/index.html', context)

def randomize(request):
    if request.method == "POST":
        print (request.POST)        
    return redirect('/')

def reset(request):
    if request.method =="POST":
        request.session.clear()
        return redirect('/')
    else:
        return redirect('/')

from __future__ import unicode_literals

from django.db import models

# Create your models here.
class Courses(models.Model):
    names=models.CharField(max_length=100)
    desc=models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

class Comments(models.Model):
    comment=models.TextField()
    cor_id=models.ForeignKey(Courses, to_field='id')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

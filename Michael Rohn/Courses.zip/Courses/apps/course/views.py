from django.shortcuts import render, redirect

from .models import Courses, Comments

# Create your views here.

def index(request):
    context={
    'data':Courses.objects.all()
    }
    return render(request, 'course/index.html', context )

def process(request):
    Courses.objects.create(names=str(request.POST['name']), desc=str(request.POST['desc']))
    return redirect ('/')

def destroy(request, c_id):
    context={
    'data':Courses.objects.get(pk=c_id)
    }
    return render(request, 'course/delete.html', context)

def delete(request, c_id):
    Courses.objects.filter(pk=c_id).delete()
    return redirect('/')

def comment(request, c_id):
    if request.POST:
        Comments.objects.create(comment=str(request.POST['com']), cor_id=c_id )
        return redirect('comment/'+str(c_id))

    else:
        context={
        'data':Courses.objects.filter(pk=c_id),
        'comm':Comments.objects.filter(cor_id=c_id),
        'id':c_id,
        }

        return render(request, 'course/comments.html', context)

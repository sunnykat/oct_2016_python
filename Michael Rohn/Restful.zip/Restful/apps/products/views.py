from django.shortcuts import render, redirect
from .models import Products
# Create your views here.

def index(request):
    context={
    'products': Products.objects.all()
    }
    return render(request, 'products/index.html', context)

def new(request):
    return render(request, 'products/new.html')

def create(request):
    Products.objects.addProduct(request.POST)
    return redirect('/')

def edit(request, p_id):
    context={
    'products': Products.objects.filter(id=p_id),
    }
    return render(request, 'products/edit.html', context)

def update(request):
    if request.method=='POST':
        Products.objects.updateProduct(request.POST)
        return redirect('/')
    else:
        return redirect('/')

def show(request,p_id):
    context={
    'products': Products.objects.filter(id=p_id)
    }
    return render(request, 'products/show.html', context)

def delete(request, p_id):
    temp=Products.objects.get(id=p_id).delete()
    return redirect('/')

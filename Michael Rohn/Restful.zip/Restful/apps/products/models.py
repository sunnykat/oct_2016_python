from __future__ import unicode_literals

from django.db import models

# Create your models here.

class ProductManager(models.Manager):
    def addProduct(self, form_data):
        Products.objects.create(name=form_data['name'],desc=form_data['desc'],price=float(form_data['price']))
        return True
    def updateProduct(self, form_data):
        update=Products.objects.get(id=form_data['id'])
        update.name=form_data['name']
        update.desc=form_data['desc']
        update.price=form_data['price']
        update.save()
        return True

class Products(models.Model):
    name=models.CharField(max_length=15)
    desc=models.CharField(max_length=40)
    price=models.DecimalField(max_digits=5, decimal_places=2)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    objects=ProductManager()

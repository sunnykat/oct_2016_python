from django.conf.urls import url, include
from . import views

urlpatterns = [
    url(r'^$', views.index, name="index"),
    url(r'^new$', views.new, name='new'),
    url(r'^create$', views.create, name="create"),
    url(r'^(?P<p_id>\d+)/edit$', views.edit, name='edit'),
    url(r'^(?P<p_id>\d+)/destroy$', views.delete, name='delete'),
    url(r'^update$', views.update, name='update'),
    url(r'^(?P<p_id>\d+$)', views.show, name='show'),
    ]

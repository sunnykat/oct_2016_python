from django.shortcuts import render, redirect

# Create your views here.
def index(request):
    context={
    "default":"No Ninjas here, buddy.",
    "who":"blank",
    }
    return render(request,'ninjas/index.html',context)

def ninjas(request):
    context={
    "default":"Check out these ninjas!",
    "who":"tmnt"
    }
    return render(request,'ninjas/index.html', context)
def brothers(request, color):
    if color=="blue":
        bro="Leonardo!"
    elif color == "orange":
        bro="Michelangelo!"
    elif color == "purple":
        bro="Donatello!"
    elif color == "red":
        bro="Raphael!"
    else:
        color="yellow"
        bro="And, uh, april. ( But not Megan Fox )"
    print color
    context={
    "default":bro,
    "who":color,

    }
    return render(request,'ninjas/index.html', context)

from django.shortcuts import render, redirect
from django.contrib import messages

from .models import User, userManager

# Create your views here.

def index(request):
    return render(request, 'validator/index.html')

def process(request):
    if not userManager.validEmail(str(request.POST['email'])):
        messages.add_message(request, messages.ERROR, 'Please provide a valid email address.')
        return redirect('/')
    if not userManager.existingEmail(str(request.POST['email'])):
        messages.add_message(request, messages.ERROR, 'This email already exisits.')
        return redirect('/')
    User.objects.create(email=str(request.POST['email']))
    messages.add_message(request, messages.SUCCESS, "The email address you entered "+str(request.POST['email'])+" is a VALID email address! Thank you!" )
    return redirect('/result')

def result(request):
    context={
    'data': User.objects.all()

    }
    return render(request, 'validator/result.html', context)

def delete(request, e_id):
    User.objects.filter(pk=e_id).delete()
    return redirect('/result')

from flask import Flask, render_template, request, redirect
app = Flask(__name__)
app.secret_key = 'ThisIsSecret'

@app.route('/')
def nothing():
    return render_template('index.html')

@app.route('/ninja')
def ninjas():
    color='tmnt'
    return render_template('ninja.html',color=color)

@app.route('/ninja/<color>')
def ninja(color):
    if color is 'blue' or 'orange' or 'purple' or 'red':
        return render_template('ninja.html', color=color)
    else:
        return render_template('ninja.html', color='yellow')

app.run(debug=True) # run our server

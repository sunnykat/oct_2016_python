from django.shortcuts import render, redirect
from datetime import datetime
import random

# Create your views here.
def index(request):
    if 'activity' not in request.session:
        request.session['activity']=[{'class':'blank','message':'Nothing so far.'}]
    if 'gold' not in request.session:
        request.session['gold']=0
    return render(request, 'gold/index.html')

def process(request,location):
    if location =='farm':
        gold=random.randint(10,20)
        request.session['gold']+=gold
    elif location =='cave':
        gold=random.randint(5,10)
        request.session['gold']+=gold

    elif location =='house':
        gold=random.randint(2,5)
        request.session['gold']+=gold

    elif location =='casino':
        gold=random.randint(-50,50)
        request.session['gold']+=gold
    elif location =='reset':
        request.session.clear()
        return redirect('/')
    else:
        return redirect('/')
    if request.session['activity'] == [{'class':'blank','message':'Nothing so far.'}]:
        request.session['activity'] = []

    time=datetime.strftime(datetime.now(), '%b-%m-%Y %I:%M:%S %p')
    message_dic={
        'class':
            "green" if gold >= 0 else "red",
        'message':
            'Earned {} gold from the {}! {}'.format(gold,location,time) if gold > 0 else 'House won... Lost {} gold from the {}! {}'.format(gold,location,time)
            }
    request.session['activity'].append(message_dic)
    return redirect('/')

class bike(object):
    def __init__(self, price=0, max=""):
        self.miles= 0
        self.price=price
        self.max_speed=max
    def displayInfo(self):
        print "Total miles so far...",self.miles
        print "Sold for",self.price
        print "Max Speed is",self.max_speed
        return self
    def ride(self):
        print "Riding..."
        self.miles+=10
        return self
    def reverse(self):
        print "Reversing..."
        if not self.miles==0:
            self.miles-=5
            return self
        else:
            return self


bike1=bike(200, '50mph')
bike2=bike(150, '25mph')
bike3=bike(500, '100mph')

bike1.ride().ride().ride().reverse().displayInfo()

bike2.ride().ride().reverse().reverse().displayInfo()

bike3.reverse().reverse().displayInfo()

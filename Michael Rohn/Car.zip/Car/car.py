class car(object):
    def display_all(self):
        print "This car gets "+str(self.mileage)+". And it has gas tank with "+str(self.fuel)+" left. A top speed of "+str(self.speed)+". A price of "+str(self.price)+" and a tax rate of "+str(self.tax)+"."
    def __init__(self,price=0, speed='0', fuel='', mileage=0):
        self.price=price
        self.speed=str(speed)+'mph'
        self.fuel=fuel
        self.mileage=mileage
        if price >10000:
            self.tax='15%'
        else:
            self.tax='12%'
        self.display_all()

car1=car(2000,35,'Full','15mpg')
car2=car(2000,5,'Not Full','105mpg')
car3=car(2000,15,'Kind of Full','95mpg')
car4=car(2000,25,'Full','25mpg')
car5=car(2000,45,'Empty','25mpg')
car6=car(2000000,35,'Empty','15mpg')

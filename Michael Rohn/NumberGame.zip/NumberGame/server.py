from flask import Flask, render_template, request, redirect, session
import random
app = Flask(__name__)
app.secret_key = 'ThisIsSecret'

def gennumber():
    try:
        session['num']=int(session['num'])
    except KeyError:
        session['num']=random.randrange(0,101)
    try:
        print session['guess']
    except UnboundLocalError:
        session['guess']=0


@app.route('/')
def index():
    gennumber()
    print session['num']
    return render_template('index.html')

@app.route('/check', methods=['POST'])
def numcheck():
    if request.form['action'] == 'inquire':
        session['guess']=int(request.form['guess'])
        return redirect('/')
    if request.form['action'] == 'reset':
        session.pop('num')
        session['guess']=0
        return redirect('/')

app.run(debug=True) # run our server

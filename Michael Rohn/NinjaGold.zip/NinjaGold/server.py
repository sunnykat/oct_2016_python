from flask import Flask, render_template, request, redirect, session
from datetime import datetime
import random
app = Flask(__name__)
app.secret_key = 'ThisIsSecret'



@app.route('/')
def status():
    try:
        print session['gold']
    except KeyError:
        session['gold']=0
    try:
        isinstance(session['activity'], list)
    except KeyError:
        session['activity']=[]

    return render_template('index.html')

@app.route('/process_money', methods=['post'])
def process():
    if request.form['action'] == 'farm':
        gold=random.randrange(10,21)
        session['gold']+=gold
        time=datetime.strftime(datetime.now(), '%Y-%m-%d %I:%M:%S %p')
        message="Earned "+str(gold)+" gold from the farm! "+time+"\n"
        session['activity'].append(message)
        return redirect('/')
    elif request.form['action'] == 'cave':
        gold=random.randrange(5,11)
        session['gold']+=gold
        time=datetime.strftime(datetime.now(), '%Y-%m-%d %I:%M:%S %p')
        message="Earned "+str(gold)+" gold from the cave! "+time+"\n"
        session['activity'].append(message)
        return redirect('/')
    elif request.form['action'] == 'house':
        session['gold']+=random.randrange(2,5)
        gold=random.randrange(2,6)
        session['gold']+=gold
        time=datetime.strftime(datetime.now(), '%Y-%m-%d %I:%M:%S %p')
        message="Earned "+str(gold)+" gold from the house! "+time+"\n"
        session['activity'].append(message)
        return redirect('/')
    elif request.form['action'] == 'casino':
        chance=random.randrange(1,100)
        if chance > 50:
            session['gold']+=random.randrange(0,50)
            gold=random.randrange(0,50)
            session['gold']+=gold
            time=datetime.strftime(datetime.now(), '%Y-%m-%d %I:%M:%S %p')
            message="Earned "+str(gold)+" gold from the casino! "+time+"\n"
            session['activity'].append(message)
            return redirect('/')
        else:
            session['gold']-=random.randrange(0,50)
            gold=random.randrange(0,50)
            session['gold']-=gold
            time=datetime.strftime(datetime.now(), '%Y-%m-%d %I:%M:%S %p')
            message="Aww... You lost "+str(gold)+" gold from the casino! "+time+"\n"
            session['activity'].append(message)
            return redirect('/')
    elif request.form['action'] == 'reset':
        session['activity']=[]
        session['gold']=0
        return redirect('/')
app.run(debug=True) # run our server

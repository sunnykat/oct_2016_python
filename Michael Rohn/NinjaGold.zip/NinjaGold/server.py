from flask import Flask, render_template, request, redirect, session
from datetime import datetime
import random
app = Flask(__name__)
app.secret_key = 'ThisIsSecret'



@app.route('/')
def status():
    try:
        print session['gold']
    except KeyError:
        session['gold']=0
    try:
        isinstance(session['activity'], dict)
    except KeyError:
        session['activity']=[]

    return render_template('index.html')

@app.route('/process_money', methods=['post'])
def process():
    if request.form['action'] == 'farm':
        gold=random.randint(10,20)
        session['gold']+=gold

    elif request.form['action'] == 'cave':
        gold=random.randint(5,10)
        session['gold']+=gold

    elif request.form['action'] == 'house':
        gold=random.randint(2,5)
        session['gold']+=gold

    elif request.form['action'] == 'casino':
        gold=random.randint(-50,50)
        session['gold']+=gold

    elif request.form['action'] == 'reset':
        session['activity']=[]
        session['gold']=0
        return redirect('/')
    time=datetime.strftime(datetime.now(), '%Y-%m-%d %I:%M:%S %p')
    message_dict={
        'class':
            "green" if gold >0 else "red",
        'message':
            'Earned {} gold from the {}! {}'.format(gold,request.form['action'],time)
        }
    session['activity'].append(message_dict)
    return redirect('/')
app.run(debug=True) # run our server

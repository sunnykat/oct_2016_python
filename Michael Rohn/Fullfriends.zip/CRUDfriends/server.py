from flask import Flask, request, redirect, render_template, session, flash
from mysqlconnection import MySQLConnector
app = Flask(__name__)
mysql = MySQLConnector(app,'friendsdb')
app.secret_key="BUTTS"
@app.route('/')
def index():
    friends=mysql.query_db("SELECT * FROM friends")
    friendcount=len(friends)
    return render_template('index.html', all_friends=friends, count=friendcount)

@app.route('/friends/<friend_id>/edit')
def show(friend_id):
    query = "SELECT * FROM friends WHERE id= :specific_id"
    data = {'specific_id':friend_id}
    friends=mysql.query_db(query,data)
    return render_template('edit.html', one_friend=friends[0])

@app.route('/friends', methods=['POST'])
def create():
    # add a friend to the database!
    query="INSERT INTO friends (first_name, last_name, email, created_at, updated_at) VALUES (:first_name,:last_name,:email,NOW(),NOW());"
    data= {'first_name': request.form['first_name'],
        'last_name':request.form['last_name'],
        'email': request.form['email']}
    mysql.query_db(query,data)
    return redirect('/')

@app.route('/friends/<friend_id>', methods=['post'])
def update(friend_id):
    friendno=friend_id
    query="UPDATE friends SET first_name =:fname , last_name=:lname, email=:email, updated_at=now() WHERE id =:id"
    data={'id': friendno, 'fname' : request.form['first'], 'lname' : request.form['last'], 'email' : request.form['em']}
    mysql.query_db(query,data)
    flash(u'Friend has been updated!')
    return redirect('/')

@app.route('/friends/<friend_id>/delete')
def destroy(friend_id):
    query="DELETE FROM friends WHERE id = :friend_id"
    data={'friend_id' : friend_id}
    mysql.query_db(query,data)
    return redirect('/')
app.run(debug=True)

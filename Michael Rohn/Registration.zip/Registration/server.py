from flask import Flask, render_template, request, redirect, session,flash
import re
import random
app = Flask(__name__)
app.secret_key = 'ThisIsSecret'
EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')
PASS_REGEX = re.compile(r'^(?=.*[A-Z])(?=.*[a-z])[a-zA-Z\d]+$')

@app.route('/')
def default():
    if 'fname' not in session:
        session['fname']=""
    if 'lname' not in session:
        session['lname']=""
    if 'email' not in session:
        session['email']=""
    return render_template('index.html')

@app.route('/submitted', methods=['post'])
def process():
    if request.form['action'] == 'process':
        session['fname']=str(request.form['first_name'])
        session['lname']=str(request.form['last_name'])
        session['email']=str(request.form['email'])
        if len(session['fname']) < 1 or str.isalpha(session['fname'])==0:
            flash(u'Must provide valid first name.')
            return redirect('/')
        elif len(session['lname']) < 1 or str.isalpha(session['lname']) == 0:
            flash(u'Must provide valid last name.')
            return redirect('/')
        elif len(session['email']) < 1:
            flash(u'Email cannot be blank!')
            return redirect('/')
        elif not EMAIL_REGEX.match(request.form['email']):
            flash(u'Invalid Email Address!')
            return redirect('/')
        elif len(request.form['pass1']) < 1 or len(request.form['pass2']) <1:
            flash(u'Password field cannot be blank!')
            return redirect('/')
        elif not str(request.form['pass1']) == str(request.form['pass2']):
            flash(u'Password fields do not match.')
            return redirect('/')
        elif not PASS_REGEX.match(request.form['pass1']):
            flash(u'Password must contain at least one Cap and one lowercase letter.')
            return redirect('/')
        else:
            session['name']="{} {}".format(session['fname'],session['lname'])
            return redirect('/results' )
    elif request.form['action'] == 'reset':
        session.clear()
        return redirect('/')
@app.route('/results')
def result():
    return render_template('result.html')

app.run(debug=True) # run our server

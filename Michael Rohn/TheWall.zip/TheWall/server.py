from flask import Flask, render_template, request, redirect, session,flash
from mysqlconnection import MySQLConnector
import re
import random
from flask.ext.bcrypt import Bcrypt
app = Flask(__name__)
bcrypt=Bcrypt(app)
mysql=MySQLConnector(app, 'loginreg')
app.secret_key = 'ThisIsSecret'
EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')
PASS_REGEX = re.compile(r'^(?=.*[A-Z])(?=.*[a-z])[a-zA-Z\d]+$')

@app.route('/')
def default():
    if 'fname' not in session:
        session['fname']=""
    if 'lname' not in session:
        session['lname']=""
    if 'email' not in session:
        session['email']=""
    return render_template('index.html')

@app.route('/submitted', methods=['post'])
def process():
    if request.form['action'] == 'process':
        session['fname']=str(request.form['first_name'])
        session['lname']=str(request.form['last_name'])
        session['email']=str(request.form['email'])
        if len(session['fname']) < 1 or str.isalpha(session['fname'])==0:
            flash(u'Must provide valid first name.', 'error')
        if len(session['lname']) < 1 or str.isalpha(session['lname']) == 0:
            flash(u'Must provide valid last name.', 'error')
        if len(session['email']) < 1:
            flash(u'Email cannot be blank!', 'error')
        if not EMAIL_REGEX.match(request.form['email']):
            flash(u'Invalid Email Address!','error')
        if len(request.form['pass1']) < 1 or len(request.form['pass2']) <1:
            flash(u'Password field cannot be blank!','error')
        if not str(request.form['pass1']) == str(request.form['pass2']):
            flash(u'Password fields do not match.','error')
        if not PASS_REGEX.match(request.form['pass1']):
            flash(u'Password must contain at least one Cap and one lowercase letter.','error')
        check=mysql.query_db("SELECT id, email FROM users")
        user_id=0
        for data in check:
            if data['email']==session['email']:
                user_id=int(data['id'])
        if not user_id == 0:
            flash(u'Email Address is arleady registered', 'error')
        try:
            if session['_flashes']:
                print 'Word'
        except KeyError:
            password=str(request.form['pass1'])
            pw_hash = bcrypt.generate_password_hash(password)
            query="INSERT INTO users (first_name,last_name,email,pw_hash,first_login,last_login,created_at,updated_at) VALUES (:fname,:lname,:email,:pw,'1',now(),now(),now())"
            data={'fname' : request.form['first_name'],'lname': request.form['last_name'],'email':request.form['email'],'pw' : pw_hash}
            mysql.query_db(query,data)
            session.clear()
            query='SELECT id FROM users WHERE email = :email'
            data={'email': request.form['email']}
            myid=mysql.query_db(query,data)
            session['id']=int(myid[0]['id'])
            return redirect('/wall/'+ str(session['id']) )
        else:
            return redirect('/')
    elif request.form['action'] == 'reset':
        return redirect('/logout')

@app.route('/logout')
def logout():
    session.clear()
    return redirect('/')

@app.route('/login', methods=['post'])
def login():
    if 'id' not in session:
        session['id']=''
    user_id=0
    email=request.form['email2']
    password=request.form['pass3']
    if len(request.form['email2']) < 1:
        flash(u'Email cannot be blank!', 'login')
        return redirect('/')
    if not EMAIL_REGEX.match(request.form['email2']):
        flash(u'Invalid Email Address!','login')
        return redirect('/')
    if len(request.form['pass3']) < 1:
        flash(u'Password field cannot be blank!','login')
        return redirect('/')
    #Insert validation for email to actually be in the database.
    check=mysql.query_db("SELECT id, email FROM users")
    for data in check:
        if data['email']==email:
            user_id=int(data['id'])
    if user_id == 0:
        flash(u'Email Address not registered', 'login')
        return redirect('/')

    query="SELECT pw_hash FROM users WHERE id = :id"
    data={'id' : user_id}
    user=mysql.query_db(query,data)
    if bcrypt.check_password_hash(user[0]['pw_hash'],password):
        session['id']=user_id
        return redirect('wall')
    else:
        flash(u'Incorrect Password','login')
        return redirect('/')


@app.route('/wall')
def result():
    if 'id' not in session:
        flash(u'Please login', 'login')
        return redirect('/')
    query="SELECT concat(first_name,' ',last_name) AS name , email, last_login FROM users WHERE id=:id"
    data={'id': session['id'] }
    user=mysql.query_db(query,data)
    query="SELECT messages.message AS message, concat(users.first_name,' ',users.last_name) AS name, messages.created_at AS created_at, messages.id AS id FROM messages LEFT JOIN users ON users.id = messages.user_id ORDER BY messages.created_at DESC"
    messages=mysql.query_db(query)
    query="SELECT comments.comment AS comment, concat(users.first_name,' ',users.last_name) AS name, comments.created_at AS created_at, comments.message_id AS com_id FROM comments LEFT JOIN messages ON messages.id = comments.message_id JOIN users ON users.id = comments.user_id"
    comments=mysql.query_db(query)
    return render_template('result.html',comments=comments, messages=messages, user=user)

@app.route('/wall/message', methods=['post'])
def addmessage():
    if 'id' not in session:
        flash(u'Please login', 'login')
        return redirect('/')
    newpost=request.form['newpost']
    if len(newpost)<1:
        flash(u'Message area cannot be blank.','error')
        return redirect('/wall')
    query="INSERT INTO messages (user_id, message, created_at, updated_at) VALUES (:session_id,:message,now(),now())"
    data={'session_id':session['id'],'message':newpost}
    mysql.query_db(query,data)
    return redirect('/wall')

@app.route('/wall/comment', methods=['post'])
def addcomment():
        if 'id' not in session:
            flash(u'Please login', 'login')
            return redirect('/')
        ncomment=request.form['newcomment']
        mid=request.form['message_id']
        print ncomment
        query="INSERT INTO comments (user_id, comment, created_at, updated_at, message_id) VALUES (:session_id,:message,now(),now(),:messid)"
        data={'session_id':session['id'],'message':ncomment, 'messid':mid}
        mysql.query_db(query,data)
        return redirect('/wall')

app.run(debug=True) # run our server

from django.shortcuts import render, redirect


# Create your views here.
def index(request):
    if not 'count' in request.session:
        request.session['count']=0
    return render(request,'form/index.html')

def submit(request):
    if request.method=='POST':
        if len(request.POST['comment'])<1 :
            comment=""
        else:
            comment=str(request.POST['comment'])
        request.session['count']+=1
        context={
            'name':str(request.POST['name']),
            'location':str(request.POST['loc']),
            'language':str(request.POST['fav']),
            'comment': comment
            }
        return render(request, 'form/result.html', context)
    else:
        return redirect('/')
